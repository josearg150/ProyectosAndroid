/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                             DESARROLLO EN ANDROID "A"
:*
:*                   SEMESTRE: AGO-DIC/2021    HORA: 10-11 HRS
:*
:*
:*
:*  Archivo     : U3WidgetsApp.java
:*  Autor       : María Guadalupe Reza Casas 17130829
:*                Juan Daniel Garcia Torres  17130789
:*  Fecha       : 17/10/2021
:*  Compilador  : Android Studio Artic Fox 2020.3.1 + JDK 11
:*  Descripci�n :
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*==========================================================================================
:*  22/09/2021  María                 Terminar app.
:*------------------------------------------------------------------------------------------*/
package mx.edu.itl.c85360673.u9widgetsapp.actividades;

import androidx.appcompat.app.AppCompatActivity;
import mx.edu.itl.c85360673.u9widgetsapp.R;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class AutoCompleteTextViewActivity extends AppCompatActivity {

    private AutoCompleteTextView _autoctxtvApellido;
    private String [] _arrApellidos = { "Vazquez", "Vasquez", "Flores", "Floriuc", "Gutierrez",
                                     "Gomez", "Gonzalez", "Gonzalitoz", "Fernandez", "Fonseca",
                                     "Sanchez", "Sosa", "Salas", "Salmeron", "Solano"   };

    //----------------------------------------------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView ( R.layout.activity_auto_complete_text_view );

        // Se crea el Adaptador usando un diseño predefinido de lista sencilla con el arreglo de apellidos
        ArrayAdapter arrayAdapter = new ArrayAdapter ( this,
                                                         android.R.layout.simple_list_item_1,
                                                         _arrApellidos );

        _autoctxtvApellido = findViewById ( R.id._autoctxtvApellido);
        _autoctxtvApellido.setThreshold ( 1 );   // El menu se desplegara a partir del 1er caracter tecleado
        _autoctxtvApellido.setAdapter  ( arrayAdapter );
    }
    //----------------------------------------------------------------------------------------------
}