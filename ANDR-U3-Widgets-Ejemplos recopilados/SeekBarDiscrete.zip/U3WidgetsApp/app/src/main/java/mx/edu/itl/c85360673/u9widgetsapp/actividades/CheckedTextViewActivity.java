/*------------------------------------------------------------------------------------------
:*                         TECNOLOGICO NACIONAL DE MEXICO
:*                       INSTITUTO TECNOLOGICO DE LA LAGUNA
:*                     INGENIERIA EN SISTEMAS COMPUTACIONALES
:*                             DESARROLLO EN ANDROID "A"
:*
:*                   SEMESTRE: AGO-DIC/2021    HORA: 10-11 HRS
:*
:*
:*
:*  Archivo     : U3WidgetsApp.java
:*  Autor       : María Guadalupe Reza Casas 17130829
:*                Juan Daniel Garcia Torres  17130789
:*  Fecha       : 17/10/2021
:*  Compilador  : Android Studio Artic Fox 2020.3.1 + JDK 11
:*  Descripci�n :
:*  Ultima modif:
:*  Fecha       Modific�             Motivo
:*==========================================================================================
:*  22/09/2021  María                 Terminar app.
:*------------------------------------------------------------------------------------------*/
package mx.edu.itl.c85360673.u9widgetsapp.actividades;

import androidx.appcompat.app.AppCompatActivity;
import mx.edu.itl.c85360673.u9widgetsapp.R;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckedTextView;

public class CheckedTextViewActivity extends AppCompatActivity {

    private CheckedTextView _chktxtvEjemplo;

    //----------------------------------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView ( R.layout.activity_checked_text_view );

        _chktxtvEjemplo = findViewById ( R.id._chktxtvEjemplo );

        // Registramos un listener del evento Click sobre el CheckedTextView
        _chktxtvEjemplo.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick ( View view ) {
                if ( _chktxtvEjemplo.isChecked () ) {
                    // Si esta marcado se cambia su estado a desmarcado y se quita la estrellita
                    _chktxtvEjemplo.setChecked ( false );
                    _chktxtvEjemplo.setCheckMarkDrawable ( null );
                } else {
                    // Si esta desmarcado se cambia a marcado y se muestra la estrellita
                    _chktxtvEjemplo.setChecked ( true );
                    _chktxtvEjemplo.setCheckMarkDrawable ( android.R.drawable.btn_star );
                }
            }
        } );
    }
    //----------------------------------------------------------------------------------------------
}